import os


def parse_directory():
    file = open('settings.txt', 'r', encoding='utf-8')
    content = file.read()

    directory = content.split('directory:')[1].strip()
    directory = directory.split("\n")[0].strip()

    directory = directory.replace("\n", "")
    return directory.strip()


def parse_ip_addr():
    file = open('settings.txt', 'r', encoding='utf-8')
    content = file.read()

    directory = content.split('ip_addr:')[1].strip()
    directory = directory.split("\n")[0].strip()

    directory = directory.replace("\n", "")
    return directory.strip()


def parse_identifier():
    file = open('settings.txt', 'r', encoding='utf-8')
    content = file.read()

    identifier = content.split('identifier:')[1].strip()
    identifier = identifier.split("\n")[0].strip()

    identifier = identifier.replace("\n", "")
    return identifier.strip()


def parse_output_dir():
    file = open('settings.txt', 'r', encoding='utf-8')
    content = file.read()

    output = content.split('output_dir:')[1].strip()
    output = output.split("\n")[0].strip()

    output = output.replace("\n", "")
    return output.strip()


def parse_port_client():
    file = open('settings.txt', 'r', encoding='utf-8')
    content = file.read()

    port = content.split('port_client:')[1].strip()
    port = port.split("\n")[0].strip()

    port = port.replace("\n", "")
    return port.strip()


def parse_ip_addr_in_array():
    ip_addr = parse_ip_addr()
    return ip_addr.split(".")


def number_of_files():
    return len(os.listdir(parse_directory()))


def size_of_dir():
    return sum(d.stat().st_size for d in os.scandir(parse_directory()) if d.is_file())


def size_of_file(file: str):
    return os.stat(file).st_size
