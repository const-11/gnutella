def parse_neighbors():
    file = open('neighbor.txt', 'r', encoding='utf-8')
    content = file.read()

    list_hosts = content.split('\n')

    neighbors = []

    for x in list_hosts:
        address = x[:x.find(":")]
        port = x[x.find(":") + 1:]

        if address == '' or port == '':
            continue

        neighbors.append((address, port))

    return neighbors